import "../style/songMenu.css";
import PlaylistMenu from "../PlaylistMenu";
import { useSong } from "../../context/SongContext";
import RemoveFromPlaylist from "./RemoveFromPlaylist";
import AddToPlaylist from "./AddToPlaylist";

export default function SongMenu({ x = 0, y = 0 }) {
  const { songMenuRef, hoveringPlaylist, setHoveringPlaylist } = useSong();
  const menuStyle = {
    position: "fixed",
    left: x,
    top: y,
    zIndex: 1000,
  };

  const handleEnter = () => {
    setHoveringPlaylist(null);
  };

  return (
    <>
      <div className="songMenu" style={menuStyle} ref={songMenuRef}>
        <AddToPlaylist />
        <p onMouseEnter={handleEnter}>Add to liked</p>
        <p onMouseEnter={handleEnter}>Add to queue</p>
        <RemoveFromPlaylist />
      </div>
      {hoveringPlaylist && (
        <PlaylistMenu
          x={hoveringPlaylist.x}
          y={hoveringPlaylist.y}
        ></PlaylistMenu>
      )}
    </>
  );
}
